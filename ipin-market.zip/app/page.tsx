const LINKS = {
  wa: "https://wa.me/6282261169349",
  tele: "https://t.me/IPINSHOP",
  groupSc: "https://chat.whatsapp.com/BOdAG1wgHq4AHVftWUWyAj",
  channelWa: "https://whatsapp.com/channel/0029VbBKScNAInPfll7NHM0O",
};

const Featured = [
  {
    key: "ipin-md-v7",
    name: "SC IPIN MD V7",
    priceText: "Mulai 55K",
    desc: "Script bot WA multifungsi + tools (removebg/vocalremover), moderasi grup, minigames, dan fitur AI voice note.",
    href: "/products/ipin-md-v7",
  },
];

export default function Home() {
  return (
    <main style={styles.bg}>
      <div style={styles.container}>
        <header style={styles.nav}>
          <div style={{ fontWeight: 900 }}>IPIN MARKET</div>
          <nav style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <a style={styles.pill} href="/products">Produk</a>
            <a style={styles.pill} href="/contact">Kontak</a>
            <a style={{ ...styles.pill, ...styles.pillPrimary }} href={LINKS.wa} target="_blank" rel="noreferrer">
              Order WhatsApp
            </a>
          </nav>
        </header>

        <section style={styles.hero}>
          <div>
            <div style={styles.kicker}>⚡ Proses cepat • UI rapi • Mobile friendly</div>
            <h1 style={styles.h1}>Website order yang simpel, modern, dan gampang dipakai.</h1>
            <p style={styles.p}>
              Fokus dulu bikin web yang keren & jelas. Nanti kalau lu siap, kita upgrade ke auto-order yang lebih full.
            </p>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 14 }}>
              <a style={{ ...styles.btn, ...styles.btnPrimary }} href="/products">Lihat Produk</a>
              <a style={styles.btn} href={LINKS.groupSc} target="_blank" rel="noreferrer">Join Grup SC</a>
              <a style={styles.btn} href={LINKS.tele} target="_blank" rel="noreferrer">Telegram</a>
            </div>
          </div>

          <div style={styles.card}>
            <div style={{ fontWeight: 900, marginBottom: 6 }}>Quick Info</div>
            <div style={styles.muted}>• Order via WA (format rapi)</div>
            <div style={styles.muted}>• Produk: panel + script + tools</div>
            <div style={styles.muted}>• Channel update tersedia</div>
            <a style={{ ...styles.btn, marginTop: 12 }} href={LINKS.channelWa} target="_blank" rel="noreferrer">
              Channel WhatsApp
            </a>
          </div>
        </section>

        <section style={{ marginTop: 18 }}>
          <h2 style={styles.h2}>Produk unggulan</h2>
          <div style={styles.grid}>
            {Featured.map((x) => (
              <a key={x.key} href={x.href} style={styles.productCard}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontWeight: 900 }}>{x.name}</div>
                  <div style={styles.badge}>{x.priceText}</div>
                </div>
                <div style={{ marginTop: 8, ...styles.muted }}>{x.desc}</div>
                <div style={{ marginTop: 12, fontWeight: 800 }}>Buka detail →</div>
              </a>
            ))}
          </div>
        </section>

        <footer style={styles.footer}>
          <div style={{ fontWeight: 900 }}>IPIN MARKET</div>
          <div style={styles.muted}>© {new Date().getFullYear()} • simple modern • responsive</div>
        </footer>
      </div>
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  bg: {
    minHeight: "100vh",
    color: "rgba(255,255,255,.92)",
    background:
      "radial-gradient(900px 450px at 15% 10%, rgba(139,92,246,.22), transparent 55%)," +
      "radial-gradient(900px 450px at 85% 20%, rgba(236,72,153,.18), transparent 55%)," +
      "linear-gradient(180deg, #060915 0%, #050715 70%, #040615 100%)",
  },
  container: { maxWidth: 1100, margin: "0 auto", padding: 16 },
  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    padding: "10px 0",
  },
  hero: {
    display: "grid",
    gridTemplateColumns: "1.2fr .8fr",
    gap: 14,
    marginTop: 14,
  },
  kicker: {
    display: "inline-block",
    padding: "7px 10px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,.12)",
    background: "rgba(255,255,255,.04)",
    fontSize: 13,
    color: "rgba(255,255,255,.78)",
  },
  h1: { fontSize: 40, lineHeight: 1.05, margin: "12px 0 10px", letterSpacing: -0.6 },
  h2: { margin: "12px 0 10px", fontSize: 18 },
  p: { margin: 0, color: "rgba(255,255,255,.68)", lineHeight: 1.6 },
  muted: { color: "rgba(255,255,255,.65)", fontSize: 13, lineHeight: 1.6 },
  pill: {
    padding: "9px 12px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,.12)",
    background: "rgba(255,255,255,.04)",
    fontSize: 14,
  },
  pillPrimary: {
    border: "none",
    background: "linear-gradient(135deg, rgba(139,92,246,.95), rgba(236,72,153,.9))",
  },
  btn: {
    display: "inline-block",
    padding: "10px 12px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,.12)",
    background: "rgba(255,255,255,.04)",
    fontWeight: 800,
  },
  btnPrimary: {
    border: "none",
    background: "linear-gradient(135deg, rgba(139,92,246,.95), rgba(236,72,153,.9))",
  },
  card: {
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,.10)",
    background: "rgba(255,255,255,.04)",
    padding: 14,
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: 12,
  },
  productCard: {
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,.10)",
    background: "rgba(255,255,255,.04)",
    padding: 14,
    textDecoration: "none",
  },
  badge: {
    fontSize: 12,
    padding: "6px 9px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,.12)",
    background: "rgba(255,255,255,.05)",
    height: "fit-content",
  },
  footer: { marginTop: 26, padding: "18px 0", display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" },
};

// Responsive quick fix
if (typeof window !== "undefined") {
  const m = window.matchMedia("(max-width: 980px)");
  const apply = () => {
    const hero = document.querySelector("section") as HTMLElement | null;
    // (biarin aja, CSS inline minimal — kalau mau rapih, nanti kita pindah ke Tailwind)
  };
  m.addEventListener?.("change", apply);
}