export default function Contact() {
  const links = [
    { name: "WhatsApp", url: "https://wa.me/6282261169349" },
    { name: "Telegram", url: "https://t.me/IPINSHOP" },
    { name: "Grup WA", url: "https://chat.whatsapp.com/LvA30WKiFgB0t5yFjFmWsz?mode=hqrc" },
    { name: "Channel WA", url: "https://whatsapp.com/channel/0029VbBKScNAInPfll7NHM0O" },
  ];

  return (
    <main style={{ padding: 16, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ margin: "8px 0 12px" }}>Kontak</h1>
      <div style={{ display: "grid", gap: 10 }}>
        {links.map(l => (
          <a key={l.name} href={l.url} target="_blank" rel="noreferrer" style={{
            border: "1px solid rgba(255,255,255,.12)",
            borderRadius: 16,
            padding: 14,
            textDecoration: "none",
            background: "rgba(255,255,255,.04)",
            color: "rgba(255,255,255,.92)"
          }}>
            <div style={{ fontWeight: 900 }}>{l.name}</div>
            <div style={{ marginTop: 6, color: "rgba(255,255,255,.65)" }}>{l.url}</div>
          </a>
        ))}
      </div>
    </main>
  );
}