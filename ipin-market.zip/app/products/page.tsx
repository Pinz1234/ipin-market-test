const products = [
  { key: "ipin-md-v7", name: "SC IPIN MD V7", priceText: "55K", desc: "Script bot WA multifungsi + tools + moderasi + games." },
];

export default function Products() {
  return (
    <main style={{ padding: 16, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ margin: "8px 0 12px" }}>Produk</h1>
      <div style={{ display: "grid", gap: 12 }}>
        {products.map(p => (
          <a key={p.key} href={`/products/${p.key}`} style={{
            border: "1px solid rgba(255,255,255,.12)",
            borderRadius: 16,
            padding: 14,
            textDecoration: "none",
            background: "rgba(255,255,255,.04)",
            color: "rgba(255,255,255,.92)"
          }}>
            <div style={{ fontWeight: 900 }}>{p.name} • {p.priceText}</div>
            <div style={{ marginTop: 6, color: "rgba(255,255,255,.65)", lineHeight: 1.6 }}>{p.desc}</div>
            <div style={{ marginTop: 10, fontWeight: 800 }}>Buka →</div>
          </a>
        ))}
      </div>
    </main>
  );
}